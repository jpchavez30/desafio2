import React, { useState, useEffect } from 'react';
import {Text, StyleSheet, View, FlatList, TouchableHighlight, TouchableWithoutFeedback, Keyboard, Platform} from 'react-native';
import Formulario from './src/components/Formulario';
import Pieza from './src/components/Pieza';
import AsyncStorage from '@react-native-async-storage/async-storage';
import Colors from './src/utils/Colors';

const App = () => {
//definir el state de piezas
const [piezas, setPiezas] = useState([]);
const [mostrarForm, guardarMostrarForm] = useState(false);

useEffect (() => {
  const obtenetPiezasStorage = async () => {
    try{
      const piezasStorage = await AsyncStorage.getItem ('piezas');
      if(piezasStorage){
        setPiezas(JSON.parse(piezasStorage));
      }
    }catch(error){
console.log(error);
    }
  }
  obtenetPiezasStorage();
},[]
);

//Eliminar pieza del state
const eliminarPieza = id => {
  const piezasFiltradas = piezas.filter(pieza => pieza.id !== id);
  setPiezas(piezasFiltradas);
  guardarPiezasStorage(JSON.stringify(piezasFiltradas));
}

//muestra u oculta el formulario
const mostrarFormulario = () => {
  guardarMostrarForm(!mostrarForm);
}
//ocultar el teclado
const cerrarTeclado = () => {
Keyboard.dismiss();
}
//almacenar las piezas en Storage
const guardarPiezasStorage = async (piezasJSON) => {
  try{
await AsyncStorage.setItem ('piezas', piezasJSON)
  }catch(error){
    console.log(error)
  }
}

return(
  <TouchableWithoutFeedback onPress={() => cerrarTeclado()}>
<View style={styles.contenedor}>
<Text style={styles.titulo}>Control de Piezas</Text>
<View>
<TouchableHighlight
onPress={()=> mostrarFormulario()}
style={styles.btnMostrarForm}>
<Text style={styles.textoMostrarForm}>
{mostrarForm ? 'cancelar Crear Pieza' : 'Crear nueva Pieza'}
</Text>
</TouchableHighlight>
</View>

<View style={styles.contenido}>
{mostrarForm ? (
  <>
  <Text style={styles.titulo}>Registro de Pieza</Text>
  <Formulario
  piezas={piezas}
  setPiezas={setPiezas}
  guardarMostrarForm={guardarMostrarForm}
  guardarPiezasStorage={guardarPiezasStorage}
  />
  </>
):(
  <>
  <Text style={styles.titulo}>
  {piezas.length > 0 ? 'Detalle de pieza' : 'No hay pieza, agrege una'}
  </Text>
  <FlatList
  style={styles.listado}
  data={piezas}
  renderItem={ ({item}) => <Pieza item={item} eliminarPieza={eliminarPieza} />}
  keyExtractor={Pieza => Pieza.id}
  />
  </>
)}
</View>
</View>
</TouchableWithoutFeedback>
);
};

const styles = StyleSheet.create({
  contenedor: {
    backgroundColor: Colors.PRIMARY_COLOR,
    flex: 1
  },
  titulo: {
    color: '#FFF',
    margintop: Platform.OS === 'ios' ? 40 : 20,
    marginBottom: 20,
    fontSize: 24,
    fontWeight: 'bold',
    textAlign: 'center'
  },
  contenido:{
    flex: 1,
    marginHorizontal: '2.5%'
  },
  listado:{
    flex: 1
  },
  btnMostrarForm: {
    padding: 10,
    backgroundColor: Colors.BUTTON_COLOR,
    marginVertical: 10
  },
  textoMostrarForm:{
    color:'#FFF',
    fontWeight: 'Bold',
    textAlign: 'center'
  }
});

export default App;