import React, { useState } from "react";
import { Text, StyleSheet, View, TextInput, Button, TouchableHighlight, Alert, ScrollView} from 'react-native';
import DateTimePickerModal from "react-native-modal-datetime-picker";
import shortid from 'react-id-generator';
import Colors from '../utils/Colors';


const Formulario = ({piezas, setPiezas, guardarMostrarForm, guardarPiezasStorage}) => {
  //variable para el formulario
  const [npieza, guardarNpieza] = useState('');
  const [marca, guardarMarca] = useState('');
  const [serie, guardarSerie] = useState('');
  const [fecha, guardarFecha] = useState('');
  
  const [isDatePickerVisible, setDatePickerVisibility] = useState('');

  const showDatePicker = () => {
    setDatePickerVisibility(true);
  };

  const hideDatePicker =() => {
    setDatePickerVisibility(false);
};

const confirmarFecha = date => {
  const opciones = { year: 'numeric', month: 'long', day: "2-digit"};
  guardarFecha(date.toLocaleDateString('es-SV', opciones));
  hideDatePicker();
};


//Crear nueva pieza
const crearNuevaPieza = () => {
  //validar
  if(npieza.trim() === '' ||
  marca.trim() === '' ||
  serie.trim() === '' ||
  fecha.trim() === '')
  {
    //falla de validacion
    mostrarAlerta();
    return;
  }

  //Crear una nueva pieza
  const pieza = { npieza, marca, serie, fecha };
  pieza.id = shortid ();
  //console.log(pieza);

  //Agregar al state
  const piezasNuevo = [...piezas, pieza];
  setPiezas(piezasNuevo);

  //Pasar las nuevas piezas a storage
  guardarPiezasStorage(JSON.stringify(piezasNuevo));

  //Ocultar el Formulario
  guardarMostrarForm(false);

  //Resetear el Formulario
  guardarNpieza('');
  guardarMarca('');
  guardarSerie('');
  guardarFecha('');
}

// Muestra la alerta si falla la Validacion
const mostrarAlerta = () => {
  Alert.alert(
    'Error', //Titulo
    'Todos los campos son obligatorios',
    [{
      text: 'OK' //Arreglo de botones
    }]
  )
}

return(
 <>
 <ScrollView style={styles.formulario}>
 <View>
 <Text style={styles.label}>Pieza:</Text>
 <TextInput style={styles.input} onChangeText={texto => guardarNpieza(texto)}/>
 </View> 

  <View>
 <Text style={styles.label}>Marca:</Text>
 <TextInput style={styles.input} onChangeText={texto => guardarMarca(texto)}/>
 </View>

  <View>
 <Text style={styles.label}>Serie:</Text>
 <TextInput style={styles.input} onChangeText={texto => guardarSerie(texto)} keyboardType='numeric'/>
 </View>

 <View>
 <Text style={styles.label}>Fecha de Cambio:</Text>
 <Button title='Seleccionar Fecha'
 onPress={showDatePicker}
 />
 <DateTimePickerModal
 isVisible={isDatePickerVisible}
 mode='date'
 onConfirm={confirmarFecha}
 onCancel={hideDatePicker}
 local='es_SV'
 headerTextIOS="Elige la fecha"
 cancelTextIOS="Cancelar"
 confirmTextIOS="Confirmar"
 />
 <Text>{fecha}</Text>
 </View>

<View>
<TouchableHighlight onPress={() => crearNuevaPieza()} style={styles.btnSubmit}>
<Text style={styles.textoSubmit}>Crear Nueva Pieza</Text>
</TouchableHighlight>
</View>
</ScrollView>
</>
);
}

const styles =StyleSheet.create({
  formulario: {
    backgroundColor: '#FFF',
    paddingHorizontal: 20,
    paddingVertical: 10,
    flex: 1
  },
  label: {
    fontWeight: 'bold',
    fontSize: 18,
    marginTop: 20
  },
  input: {
    marginTop: 10,
    height: 50,
    borderColor: '#E1E1E1',
    borderWidth:1,
    borderStyle: 'solid'
  },
  btnSubmit:{
    padding:10,
    backgroundColor:Colors.BUTTON_COLOR,
    marginVertical:10
  },
  textoSubmit: {
    color: '#FFF',
    fontWeight: 'bold',
    textAlign: 'center'
  }
})
export default Formulario;